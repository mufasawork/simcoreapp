<div class="row">
	<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
		<div><?php echo $output; ?></div>
	</div>
</div>
