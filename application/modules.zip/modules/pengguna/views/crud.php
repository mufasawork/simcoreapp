<div class="row">
	<div class="col-xl-8 col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<?= message_box('success', TRUE)?>
		<?= message_box('warning', TRUE)?>
	</div>
	<div class="col-lg-8 col-md-10 col-sm-12 col-xs-12">
		<div><?php echo $output; ?></div>
	</div>
</div>
