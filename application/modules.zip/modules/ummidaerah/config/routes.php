<?php


$route['ummidaerah/agenda/(:any)'] = 'agenda/index/$1';
