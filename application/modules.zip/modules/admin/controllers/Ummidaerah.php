<?php defined("BASEPATH") or exit("No direct script access allowed");

/**
 * Ummidaerah Controller.
 */
class Ummidaerah extends MY_Controller
{
    public function area()
	{
		$crud = new grocery_CRUD();
		
		$crud->set_table("ummi_daerah_area");
		$crud->set_subject("");

		// Show in
		$crud->add_fields(["ummi_daerah_id", "provinsi_id", "kabupaten_id"]);
		$crud->edit_fields(["ummi_daerah_id", "provinsi_id", "kabupaten_id"]);
		$crud->columns(["ummi_daerah_id", "provinsi_id", "kabupaten_id"]);

		// Fields type
		$crud->field_type("id", "integer");
		$crud->set_relation("ummi_daerah_id", "ummi_daerah", "ummi_daerah");

        // Relation n-n
        $crud->set_relation('provinsi_id','wilayah_provinsi','provinsi');
        $crud->set_relation('kabupaten_id', 'wilayah_kabupaten', 'kabupaten');
		

		// Validation
		$crud->set_rules("ummi_daerah_id", "Ummi daerah id", "required");

		// Display As

        // Unset action
        $crud->unset_read();

        
        // Dependet Dropdown
		$this->load->library('gc_dependent_select');
        
        $fields = array(
            // provinsi
            'provinsi_id' => array(
                'table_name' => 'wilayah_provinsi',
                'title'      => 'provinsi',
                'relate'     => null
            ),

            // kabupaten
            'kabupaten_id' => array(
                'table_name' => 'wilayah_kabupaten',
                'title'      => 'kabupaten',
                'id_field'   => 'id',
                'relate'     => 'provinsi_id',
                'data-placeholder' => 'pilih kabupaten'
            )
            
        );
        
        $config = array(
            'main_table' => 'ummi_daerah_area',
            'main_table_primary' => 'id',
            'url' => base_url().'admin/' . __CLASS__ . '/' . __FUNCTION__ . '/', //path to method
        );
        
        $wilayah = new gc_dependent_select($crud, $fields, $config);
        
        $js = $wilayah->get_js();
        
        $output = $crud->render();
        $output->output .= $js;
        
		$data = (array) $output;

		$this->layout->set_wrapper( 'grocery', $data,'page', false);

		$template_data['grocery_css'] = $data['css_files'];
		$template_data['grocery_js']  = $data['js_files'];
		$template_data["title"] = "Ummi Daerah Area";
		$template_data["crumb"] = [];
		$this->layout->auth();
		$this->layout->render('admin', $template_data); // front - auth - admin
	}

}