<?php

defined('BASEPATH') or exit('No direct script access allowed');
/**
 * Smart model.
 */
class Pengguna_model extends MY_Model
{

    

}