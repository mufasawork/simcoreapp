

<div class="row">
	<div class="col-lg-12">
        <!-- View massage -->
        <?php echo message_box('success'); ?>
        <?php echo message_box('error'); ?>
        
		<div><?php echo $output; ?></div>
	</div>
</div>
